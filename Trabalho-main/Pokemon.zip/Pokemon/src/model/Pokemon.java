package model;

public class Pokemon {
}
