package model;

public class Pokedex {
}
