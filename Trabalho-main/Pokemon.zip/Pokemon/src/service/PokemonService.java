package service;

public class PokemonService {
}
