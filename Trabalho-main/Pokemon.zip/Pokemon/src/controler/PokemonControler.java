package controler;

public class PokemonControler {
}
